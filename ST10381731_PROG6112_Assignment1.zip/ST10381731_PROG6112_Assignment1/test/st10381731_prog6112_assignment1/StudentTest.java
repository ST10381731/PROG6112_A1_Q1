/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10381731_prog6112_assignment1;

import java.io.ByteArrayInputStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author emilio
 */
public class StudentTest {

    public StudentTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    
    @Test
    public void testSaveStudent() {
        ByteArrayInputStream in = new ByteArrayInputStream("id123\nname123\n16\nemail123@gmail.com\nCOURSE123".getBytes());
        System.setIn(in);
        Student instance = new Student();
        instance.SaveStudent();
        
        assertEquals("id123", instance.getId());
        assertEquals("name123", instance.getName());
        assertEquals(16, instance.getAge());
        assertEquals("email123@gmail.com", instance.getEmail());
        assertEquals("COURSE123", instance.getCourse());
    }

    
    @Test
    public void testSearchStudent() {
        ByteArrayInputStream in = new ByteArrayInputStream("id123\nname123\n16\nemail123@gmail.com\nCOURSE123".getBytes());
        System.setIn(in);
        Student instance = new Student();
        instance.SaveStudent();

        ByteArrayInputStream in2 = new ByteArrayInputStream("id123".getBytes());
        System.setIn(in2);
        boolean result = instance.SearchStudent();
        assertTrue(result);       

    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        ByteArrayInputStream in = new ByteArrayInputStream("id123\nname123\n16\nemail123@gmail.com\nCOURSE123".getBytes());
        System.setIn(in);
        Student instance = new Student();
        instance.SaveStudent();

        ByteArrayInputStream in2 = new ByteArrayInputStream("id124".getBytes());
        System.setIn(in2);
        boolean result = instance.SearchStudent();
        assertTrue(!result);    
    }

    
    @Test
    public void testDeleteStudent() {
        ByteArrayInputStream in = new ByteArrayInputStream("id123\nname123\n16\nemail123@gmail.com\nCOURSE123".getBytes());
        System.setIn(in);
        Student instance = new Student();
        instance.SaveStudent();

        ByteArrayInputStream in2 = new ByteArrayInputStream("id123".getBytes());
        System.setIn(in2);
        boolean result = instance.SearchStudent();
        assertTrue(result);    
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        ByteArrayInputStream in = new ByteArrayInputStream("id123\nname123\n16\nemail123@gmail.com\nCOURSE123".getBytes());
        System.setIn(in);
        Student instance = new Student();
        instance.SaveStudent();

        ByteArrayInputStream in2 = new ByteArrayInputStream("id124".getBytes());
        System.setIn(in2);
        boolean result = instance.SearchStudent();
        assertTrue(!result);    
    }

     @Test
    public void testStudentAge_StudentAgeValid() {
        Student instance = new Student();
        assertTrue(instance.StudentAge(18));
    }

    @Test
    public void testStudentAge_StudentAgeInvalid() {
        Student instance = new Student();
        assertFalse(instance.StudentAge(15));
    }

    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        Student instance = new Student();
        assertFalse(instance.StudentAge("abc"));
    }

    
    @Test
    public void testStudentReport() {
        System.out.println("StudentReport");
        Student instance = new Student();
        instance.StudentReport();
        
    }



}
