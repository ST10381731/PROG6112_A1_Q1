/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10381731_prog6112_assignment1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author emilio
 */
public class ST10381731_PROG6112_Assignment1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student student = new Student();
        Scanner kb = new Scanner(System.in);

        boolean exitApplication = false;

        do {
            System.out.println("\nSTUDENT MANAGEMENT APPLICATION"
                    + "\n****************************************"
                    + "\nEnter (1) to launch menu or any other key to exit");

            String launchKey = kb.next();

            if (launchKey.equals("1")) {
                String menuChoice = "";

                boolean btrue = true;
                do {
                    System.out.println("\nPlease select one of the following menu items:"
                            + "\n(1) Capture a new student."
                            + "\n(2) Search for a student."
                            + "\n(3) Delete a student."
                            + "\n(4) Print student report."
                            + "\n(5) Exit Application.");
                    menuChoice = kb.next();
                    if (menuChoice.equalsIgnoreCase("1")) {
                        student.SaveStudent();
                    } else if (menuChoice.equalsIgnoreCase("2")) {
                        student.SearchStudent();
                    } else if (menuChoice.equalsIgnoreCase("3")) {
                        student.DeleteStudent();
                    } else if (menuChoice.equalsIgnoreCase("4")) {
                        student.StudentReport();
                    } else if (menuChoice.equalsIgnoreCase("5")) {
                        btrue = false;
                    }
                } while (btrue);

            } else {
                student.ExitStudentApplication();
                exitApplication = true;
            }

        } while (!exitApplication);
    }
}
