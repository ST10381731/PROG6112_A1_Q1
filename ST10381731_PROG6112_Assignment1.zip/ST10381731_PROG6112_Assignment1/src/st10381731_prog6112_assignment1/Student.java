/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10381731_prog6112_assignment1;

import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author emilio
 */
public class Student {

    private String name;
    private int age;
    private String id;
    private String course;
    private String email;
    private ArrayList<Student> studentList = new ArrayList<>();
    Scanner kb = new Scanner(System.in);

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getId() {
        return id;
    }

    public String getCourse() {
        return course;
    }

    public String getEmail() {
        return email;
    }

    public ArrayList<Student> getStudentList() {
        return studentList;
    }

    public boolean StudentAge(int age) {
        return age >= 16;
    }

    public boolean StudentAge(String age) {
        try {
            int parsedAge = Integer.parseInt(age);
            return parsedAge >= 16;
        } catch (NumberFormatException e) {
            return false; 
        }
    }



    public void SaveStudent() {
        Scanner kb = new Scanner(System.in);

        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("************************************");

        System.out.print("Enter the student id: ");
        id = kb.nextLine();

        System.out.print("Enter the student name: ");
        name = kb.nextLine();

        int enteredAge;
        do {
            System.out.print("Enter the student age: ");
            while (!kb.hasNextInt()) {
                System.out.println("Invalid input. Please enter a valid age.");
                kb.next();
            }
            enteredAge = kb.nextInt();
            kb.nextLine();

            if (enteredAge < 16) {
                System.out.println("Invalid age. Please enter an age greater than or equal to 16.");
            }
        } while (enteredAge < 16);
        age = enteredAge;

        System.out.print("Enter the student email: ");
        email = kb.nextLine();

        System.out.print("Enter the student course: ");
        course = kb.nextLine();

        Student newStudent = new Student();
        newStudent.id = id;
        newStudent.name = name;
   
        newStudent.age = age;
        newStudent.email = email;
        newStudent.course = course;
        studentList.add(newStudent);

        System.out.println("Student information saved.");
    }

    public boolean SearchStudent() {
        Scanner kb = new Scanner(System.in);

        System.out.println("Enter student ID to search:");
        String searchId = kb.nextLine();
        System.out.println("----------------------------------");
        boolean found = false;
        for (Student student : studentList) {
            if (student.id.equals(searchId)) {
                System.out.println("STUDENT ID: " + student.id);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.course);
                System.out.println("----------------------------------");
                found = true;
                break;
            }

        }

        if (!found) {
            System.out.println("Student with ID: " + searchId + " was not found.");
            System.out.println("----------------------------------");
        }

        return found;
    }

    public boolean DeleteStudent() {
        Scanner kb = new Scanner(System.in);

        System.out.println("DELETE STUDENT");
        System.out.println("===============================================");

        System.out.print("Enter the student id to delete: ");
        String deleteId = kb.nextLine();

        Student studentToDelete = null;
        for (Student student : studentList) {
            if (student.id.equals(deleteId)) {
                studentToDelete = student;
                break;
            }
        }

        if (studentToDelete != null) {
            System.out.println("Are you sure you want to delete student " + studentToDelete.id + " from the system? Yes (y) to delete or no (n)");

            String confirmation = kb.next();
            if (confirmation.equalsIgnoreCase("y")) {
                studentList.remove(studentToDelete);
                System.out.println("----------------------------------------------------");
                System.out.println("Student with Student ID: " + deleteId + " was deleted!");
                System.out.println("----------------------------------------------------");
            } else {
                System.out.println("Student deletion was canceled.");
            }

            return true;
        } else {
            System.out.println("Student with ID " + deleteId + " not found.");
            return false;
        }
    }

    public boolean testStudentAge() {
        Scanner kb = new Scanner(System.in);

        System.out.println("Enter student ID to search:");
        String searchId = kb.nextLine();
        System.out.println("----------------------------------");
        boolean found = false;
        for (Student student : studentList) {
            if (student.id.equals(searchId)) {
                System.out.println("STUDENT ID: " + student.id);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.course);
                System.out.println("----------------------------------");
                found = true;
                break;
            }

        }

        if (!found) {
            System.out.println("Student with ID: " + searchId + " was not found.");
            System.out.println("----------------------------------");
        }

        return found;
    }

    public void StudentReport() {
        if (studentList.isEmpty()) {
            System.out.println("No students to generate a report for.");
            return;
        }
        int count = 1;

        for (Student student : studentList) {
            System.out.println("STUDENT " + count);
            System.out.println("-----------------------------------------------");
            System.out.println("ID: " + student.id);
            System.out.println("NAME: " + student.name);
            System.out.println("AGE: " + student.age);
            System.out.println("EMAIL: " + student.email);
            System.out.println("COURSE: " + student.course);
            System.out.println("-----------------------------------------------");
            count += 1;
        }
    }

    public void ExitStudentApplication() {
        System.out.println("Exiting application");
    }

    
}
